The 'data/input' directory must include the following files and subdirectory:

hybas_eu_lev04_v1c.dbf
hybas_eu_lev04_v1c.prj
hybas_eu_lev04_v1c.sbn
hybas_eu_lev04_v1c.sbx
hybas_eu_lev04_v1c.shp
hybas_eu_lev04_v1c.shp.xml
hybas_eu_lev04_v1c.shx
hybas_eu_lev12_v1c.dbf
hybas_eu_lev12_v1c.prj
hybas_eu_lev12_v1c.sbn
hybas_eu_lev12_v1c.sbx
hybas_eu_lev12_v1c.shp
hybas_eu_lev12_v1c.shp.xml
hybas_eu_lev12_v1c.shx
pfas_data.parquet
