The 'data/dataset_generation' directory must include the following files and subdirectory:

│   2026-09-14_pdh_surface_water_sampling_relevant_parameters.parquet
│   2026-09-23_Basel-Rhein.csv
│   2026-09-23_Basel.csv
│   2026-09-23_Rijkswaterstaat.csv
│   2026-10-01_Einzelwerte Chemie.xlsx
│   bfg_pfas.gpkg
│   ez4c01126_si_002.xlsx
│   PFAS_ in_sediment_35_targeted_PFAS.csv
│   PFAS_in_sediment_30PFAS_TOP_Assay.csv
│   PFAS_in_water_34_targeted_PFAS.csv
│
└───auxiliary
        hybas_eu_lev01_v1c.dbf
        hybas_eu_lev01_v1c.prj
        hybas_eu_lev01_v1c.sbn
        hybas_eu_lev01_v1c.sbx
        hybas_eu_lev01_v1c.shp
        hybas_eu_lev01_v1c.shp.xml
        hybas_eu_lev01_v1c.shx
        hybas_eu_lev04_v1c.dbf
        hybas_eu_lev04_v1c.prj
        hybas_eu_lev04_v1c.sbn
        hybas_eu_lev04_v1c.sbx
        hybas_eu_lev04_v1c.shp
        hybas_eu_lev04_v1c.shp.xml
        hybas_eu_lev04_v1c.shx
        ne_10m_admin_0_countries.cpg
        ne_10m_admin_0_countries.dbf
        ne_10m_admin_0_countries.prj
        ne_10m_admin_0_countries.README.html
        ne_10m_admin_0_countries.shp
        ne_10m_admin_0_countries.shx
        ne_10m_admin_0_countries.VERSION.txt
